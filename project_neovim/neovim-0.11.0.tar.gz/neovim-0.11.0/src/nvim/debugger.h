#pragma once

#include "nvim/ex_cmds_defs.h"  // IWYU pragma: keep

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "debugger.h.generated.h"
#endif
